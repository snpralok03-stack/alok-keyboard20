# Alok Keyboard — Android IME Project

Complete native Kotlin Android keyboard (`InputMethodService`) featuring the dark QWERTY layout with number row, Shift, Backspace, Enter, Emoji, Language toggle (English / Hinglish), and a top bar of five live-preview text transformation buttons:

- **MONO**: `alok` → `a l o k`
- **BANANA**: `alok` → `aa ll oo kk`
- **ALTERNATE**: `alok` → `AlOk`
- **REVERSE**: `alok` → `kola`
- **CHIPKU**: `alok` → `aallookk`

## Project Structure

- `app/src/main/AndroidManifest.xml` — IME service declaration (`BIND_INPUT_METHOD`) and setup launcher activity.
- `app/src/main/java/com/alok/keyboard/ime/AlokInputMethodService.kt` — Core `InputMethodService` handling word extraction, live preview updates, and atomic word replacement.
- `app/src/main/java/com/alok/keyboard/ime/AlokKeyboardView.kt` — Custom dark-theme QWERTY + Number Row + Emoji + Symbols keyboard view.
- `app/src/main/java/com/alok/keyboard/transform/TextTransformer.kt` — Pure Kotlin transformation engine (`MONO`, `BANANA`, `ALTERNATE`, `REVERSE`, `CHIPKU`).
- `app/src/main/java/com/alok/keyboard/ui/SetupActivity.kt` — Companion screen to enable/select Alok Keyboard and test words in a sandbox.
- `app/src/main/res/layout/keyboard_container.xml` — Horizontal 5-button transformation bar stacked directly above the dark keyboard.
- `app/src/main/res/xml/method.xml` — Android IME subtypes (`en_IN` and Hinglish `hi_IN`).
- `app/src/test/java/com/alok/keyboard/transform/TextTransformerTest.kt` — JUnit test suite verifying `alok`, `hello`, `india`, `computer`, and `HELLO`.

## Building the APK

### Option A: Android Studio (Desktop)
1. Extract `AlokKeyboard.zip`.
2. Open Android Studio → **Open** → select the `AlokKeyboard` folder.
3. Wait for Gradle sync to finish.
4. Go to **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Output APK path: `app/build/outputs/apk/debug/app-debug.apk`.

### Option B: Directly on Android Phone (Termux or AndroidIDE)
1. **Using AndroidIDE (Recommended on Mobile):**
   - Install **AndroidIDE** on your Android device.
   - Extract `AlokKeyboard.zip` into your device storage.
   - Open the `AlokKeyboard` folder in AndroidIDE and tap the **Run / Build** button to compile and install the debug APK directly.
2. **Using Termux:**
   - Install packages: `pkg install openjdk-17 gradle`
   - Extract `AlokKeyboard.zip` and `cd AlokKeyboard`
   - Run `gradle assembleDebug`
   - Install the generated APK from `app/build/outputs/apk/debug/app-debug.apk`.

## Enabling Alok Keyboard on Android
1. Install the built APK and open **Alok Keyboard**.
2. Tap **1. Enable in Android Settings** and toggle **Alok Keyboard** ON.
3. Return to the app and tap **2. Select Alok Keyboard** (or tap the keyboard switcher icon on your navigation bar).
4. Type any word in the test box (or any app) and tap **MONO**, **BANANA**, **ALTERNATE**, **REVERSE**, or **CHIPKU** to replace the word in place.

## Patch notes
See `BUILD_STATUS.txt` for the fixes applied and the build-validation limitation. The symbols keyboard Kotlin string literals and selected-text replacement handling have been corrected.
