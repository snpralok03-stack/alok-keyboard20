package com.alok.keyboard.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.alok.keyboard.R

class SetupActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var etSandbox: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setup)

        tvStatus = findViewById(R.id.tv_ime_status)
        etSandbox = findViewById(R.id.et_test_sandbox)

        findViewById<Button>(R.id.btn_enable_ime).setOnClickListener {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }

        findViewById<Button>(R.id.btn_select_ime).setOnClickListener {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }

        findViewById<Button>(R.id.btn_clear_sandbox).setOnClickListener {
            etSandbox.setText("")
            etSandbox.requestFocus()
        }
    }

    override fun onResume() {
        super.onResume()
        updateImeStatus()
    }

    private fun updateImeStatus() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        val enabledList = imm.enabledInputMethodList
        val isEnabled = enabledList.any { it.packageName == packageName }

        val currentIme = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: ""
        val isSelected = currentIme.startsWith(packageName)

        tvStatus.text = when {
            isSelected -> "Status: Alok Keyboard is ENABLED and ACTIVE"
            isEnabled -> "Status: Enabled in Settings — Tap 'Select Alok Keyboard' below"
            else -> "Status: Not enabled yet — Tap '1. Enable in Settings' first"
        }
    }
}
