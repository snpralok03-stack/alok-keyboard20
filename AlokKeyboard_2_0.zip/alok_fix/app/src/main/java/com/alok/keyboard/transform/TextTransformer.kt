package com.alok.keyboard.transform

enum class TransformType(val label: String) {
    MONO("MONO"),
    BANANA("BANANA"),
    ALTERNATE("ALTERNATE"),
    REVERSE("REVERSE"),
    CHIPKU("CHIPKU")
}

object TextTransformer {

    /**
     * Transforms a single word according to the selected transformation style.
     * Supports uppercase, lowercase, English, and Hinglish seamlessly.
     */
    fun transform(word: String, type: TransformType): String {
        if (word.isEmpty()) return ""
        return when (type) {
            TransformType.MONO -> toMono(word)
            TransformType.BANANA -> toBanana(word)
            TransformType.ALTERNATE -> toAlternate(word)
            TransformType.REVERSE -> toReverse(word)
            TransformType.CHIPKU -> toChipku(word)
        }
    }

    /**
     * MONO: Inserts a single space between every character.
     * Example: "alok" -> "a l o k"
     */
    fun toMono(word: String): String {
        if (word.length <= 1) return word
        val sb = StringBuilder(word.length * 2 - 1)
        for (i in word.indices) {
            if (i > 0) sb.append(' ')
            sb.append(word[i])
        }
        return sb.toString()
    }

    /**
     * BANANA: Duplicates every character and separates pairs with a single space.
     * Example: "alok" -> "aa ll oo kk"
     */
    fun toBanana(word: String): String {
        val sb = StringBuilder(word.length * 3)
        for (i in word.indices) {
            if (i > 0) sb.append(' ')
            val c = word[i]
            sb.append(c).append(c)
        }
        return sb.toString()
    }

    /**
     * ALTERNATE: Alternating uppercase and lowercase characters starting with uppercase.
     * Example: "alok" -> "AlOk", "HELLO" -> "HeLlO"
     */
    fun toAlternate(word: String): String {
        val sb = StringBuilder(word.length)
        var letterIndex = 0
        for (c in word) {
            if (c.isLetter()) {
                if (letterIndex % 2 == 0) {
                    sb.append(c.uppercaseChar())
                } else {
                    sb.append(c.lowercaseChar())
                }
                letterIndex++
            } else {
                sb.append(c)
            }
        }
        return sb.toString()
    }

    /**
     * REVERSE: Reverses the exact character sequence preserving case.
     * Example: "alok" -> "kola"
     */
    fun toReverse(word: String): String {
        return word.reversed()
    }

    /**
     * CHIPKU: Duplicates every character continuously with no spaces.
     * Example: "alok" -> "aallookk"
     */
    fun toChipku(word: String): String {
        val sb = StringBuilder(word.length * 2)
        for (c in word) {
            sb.append(c).append(c)
        }
        return sb.toString()
    }

    /**
     * Extracts the active word immediately preceding the cursor.
     * Stops at whitespace or standard sentence delimiters so Hinglish/English words
     * are accurately isolated without affecting previous words.
     */
    fun extractCurrentWordBeforeCursor(textBeforeCursor: CharSequence?): String {
        if (textBeforeCursor.isNullOrEmpty()) return ""
        var start = textBeforeCursor.length
        while (start > 0) {
            val ch = textBeforeCursor[start - 1]
            if (isWordChar(ch)) {
                start--
            } else {
                break
            }
        }
        return textBeforeCursor.subSequence(start, textBeforeCursor.length).toString()
    }

    fun isWordChar(ch: Char): Boolean {
        return ch.isLetterOrDigit() || ch == '\'' || ch == '-' || ch == '_'
    }
}
